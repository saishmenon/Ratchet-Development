-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2017 at 06:10 AM
-- Server version: 5.5.52-MariaDB
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ratchet_research`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `parent` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `name`, `parent`) VALUES
(1, 'ELECTRONICS', NULL),
(2, 'TELEVISIONS', 1),
(3, 'TUBE', 2),
(4, 'LCD', 2),
(5, 'PLASMA', 2),
(6, 'PORTABLE ELECTRONICS', 1),
(7, 'MP3 PLAYERS', 6),
(8, 'FLASH', 7),
(9, 'CD PLAYERS', 6),
(10, '2 WAY RADIOS', 6);

-- --------------------------------------------------------

--
-- Table structure for table `ratchet_children`
--

CREATE TABLE IF NOT EXISTS `ratchet_children` (
  `node_id` int(255) NOT NULL,
  `child_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratchet_children`
--

INSERT INTO `ratchet_children` (`node_id`, `child_id`) VALUES
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(3, 6),
(3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `ratchet_description`
--

CREATE TABLE IF NOT EXISTS `ratchet_description` (
  `id` int(255) NOT NULL,
  `node_id` int(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `description_owner` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratchet_description`
--

INSERT INTO `ratchet_description` (`id`, `node_id`, `description`, `description_owner`) VALUES
(1, 1, 'Root Node', 'Saish'),
(2, 2, 'A - First Child of root node', 'Saish'),
(3, 3, 'B - Second Child of the root node.', 'Dan'),
(4, 4, 'First Child of A - Son of A', 'Saish'),
(5, 5, 'Second Child of A - Daughter of A', 'Dan'),
(6, 6, 'First Child of A - Son of B', 'Dan'),
(7, 7, 'Second Child of B - Daughter of B', 'Dan');

-- --------------------------------------------------------

--
-- Table structure for table `ratchet_node`
--

CREATE TABLE IF NOT EXISTS `ratchet_node` (
  `node_id` int(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `owner` varchar(20) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `parent` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratchet_node`
--

INSERT INTO `ratchet_node` (`node_id`, `title`, `owner`, `timestamp`, `parent`) VALUES
(1, 'Root Node', 'saish', '2016-11-04 18:03:00', 0),
(2, 'Node A', 'saish', '2016-11-04 18:03:00', 1),
(3, 'Node B', 'saish', '2016-11-04 18:13:01', 1),
(4, 'Son of A', 'Dan', '2016-11-24 11:08:53', 2),
(5, 'Daughter of A', 'Dan', '2016-11-24 11:09:36', 2),
(6, 'Son of B', 'Dan', '2016-11-24 11:10:08', 3),
(7, 'Daughter of B', 'Dan', '2016-11-24 11:10:27', 3);

-- --------------------------------------------------------

--
-- Table structure for table `ratchet_vote`
--

CREATE TABLE IF NOT EXISTS `ratchet_vote` (
  `node_id` int(255) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `upvote` int(255) NOT NULL,
  `downvote` int(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratchet_vote`
--

INSERT INTO `ratchet_vote` (`node_id`, `ip`, `upvote`, `downvote`) VALUES
(1, '129.21.132.148', 1, 0),
(2, '129.21.132.148', 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ratchet_children`
--
ALTER TABLE `ratchet_children`
  ADD PRIMARY KEY (`node_id`,`child_id`);

--
-- Indexes for table `ratchet_description`
--
ALTER TABLE `ratchet_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratchet_node`
--
ALTER TABLE `ratchet_node`
  ADD PRIMARY KEY (`node_id`);

--
-- Indexes for table `ratchet_vote`
--
ALTER TABLE `ratchet_vote`
  ADD PRIMARY KEY (`node_id`,`ip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `ratchet_description`
--
ALTER TABLE `ratchet_description`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ratchet_node`
--
ALTER TABLE `ratchet_node`
  MODIFY `node_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ratchet_vote`
--
ALTER TABLE `ratchet_vote`
  MODIFY `node_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
